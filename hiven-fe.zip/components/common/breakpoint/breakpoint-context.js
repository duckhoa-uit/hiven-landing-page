import React from 'react';

export const BreakpointContext = React.createContext({
   windowWidth: 0,
});
