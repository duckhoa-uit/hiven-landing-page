import { Box, Button, ListItem } from '@mui/material';
import NextLink from 'next/link';
import { useRouter } from 'next/router';
import PropTypes from 'prop-types';

export const NavItem = (props) => {
   const { href, icon, title, ...others } = props;
   const router = useRouter();
   const active = href ? router.pathname.split('/')[2] === href.split('/')[2] : false;

   return (
      <ListItem
         disableGutters
         sx={{
            display: 'flex',
            mb: 0.5,
            py: 0,
            px: 2,
         }}
         {...others}
      >
         <NextLink href={href} passHref>
            <Button
               component="a"
               startIcon={icon}
               disableRipple
               sx={{
                  backgroundColor: active ? 'rgba(255,255,255, 0.08)' : 'transparent',
                  borderRadius: 1,
                  color: active ? '#c32f5b' : '#fff',
                  // fontWeight: active && 'fontWeightBold',
                  justifyContent: 'flex-start',
                  px: 3,
                  textAlign: 'left',
                  textTransform: 'none',
                  width: '100%',
                  '& .MuiButton-startIcon': {
                     color: active ? '#c32f5b' : '#fff',
                  },
                  '&:hover': {
                     backgroundColor: 'rgba(255,255,255, 0.08)',
                  },
               }}
            >
               <Box sx={{ flexGrow: 1, fontSize: 16 }}>{title}</Box>
            </Button>
         </NextLink>
      </ListItem>
   );
};

NavItem.propTypes = {
   href: PropTypes.string,
   icon: PropTypes.node,
   title: PropTypes.string,
};
