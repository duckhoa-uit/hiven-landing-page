import * as React from 'react';

export function EmptyLayout({ children }) {
   return <>{children}</>;
}
